package com.mgnrega.login;

//import com.mgnrega.*;

public class Main {
	public static void main(String[] args) {		
		
		// This is the main file
		// Applications starts from here... 

		System.out.println("-------------------------------------------------------------");
		System.out.println("<==========  Welcome To MGNREGA Mini Project ================>");
		System.out.println("-------------------------------------------------------------");
		
		UserActivity.selectUser();
		
	}

}
