package com.mgnrega.exceptions;

public class GpmException extends Exception{
	

	public GpmException() {
		// TODO Auto-generated constructor stub
	}
	
	public GpmException(String message) {
		super(message);
	}

}
