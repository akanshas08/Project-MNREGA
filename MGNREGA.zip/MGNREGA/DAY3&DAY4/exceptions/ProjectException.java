package com.mgnrega.exceptions;

public class ProjectException extends Exception{
	
	public ProjectException() {
		// TODO Auto-generated constructor stub
	}
	
	public ProjectException(String message) {
		super(message);
	}


}
