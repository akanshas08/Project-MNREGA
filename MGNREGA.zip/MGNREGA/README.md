

   ## This Project is created by Akansha Singhal ##

# MGNREGA (Mini_Project_Console_Base)

MNREGA(The Mahatma Gandhi National Rural Employment Guarantee Act ) is a scheme by which unskilled people of rural India are guaranteed to have 100 days of paid work. Main objective of this project is to manage employments offered through this scheme.There are two users of this system !


## Project  Details

- There are several functionalities with respect to-

- BDO (Block Development Officer).

- GPM (Gram Panchayat Member).



## Important Credentials

- BDO
   - Email_id - akansha@123

   - Password - akansha123

- GPM
   - Email_id - akansha@123

   - Password - akansha123
   
   

   
   

